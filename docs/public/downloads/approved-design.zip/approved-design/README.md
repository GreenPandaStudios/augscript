# Modules and composition

Startup combines narrow domain exports with a scoped counter provider. Records and validation keep data and checked failures visible.

Install August as described at https://greenpandastudios.github.io/augscript/getting-started. Native commands prepare required libraries automatically.

From the folder containing this extracted project:

```sh
cd approved-design
aug check .
aug spec .
aug test .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/approved-design/.
