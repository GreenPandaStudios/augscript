# A small tested application

A calculator logs each addition. Its nearby tests replace the logger and verify both labeled inputs and fresh setup.

Install August as described at https://greenpandastudios.github.io/augscript/getting-started. Native commands prepare required libraries automatically.

From the folder containing this extracted project:

```sh
cd developer-workflow
aug check .
aug spec .
aug test .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/developer-workflow/.
