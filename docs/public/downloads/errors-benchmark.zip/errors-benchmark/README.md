# Checked-error benchmark

Interleave successful calls and caught checked failures.

Install August as described at https://greenpandastudios.github.io/augscript/getting-started. Native commands prepare required libraries automatically.

From the folder containing this extracted project:

```sh
cd errors-benchmark
aug check .
aug spec .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/errors-benchmark/.
