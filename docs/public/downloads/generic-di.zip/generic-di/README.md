# Generic dependency injection

Bind a generic interface and resolve a class that uses it.

Prepare native dependencies as described at https://greenpandastudios.github.io/augscript/packages#npm-registry.

From the folder containing this extracted project:

```sh
cd generic-di
npx @greenpandastudios/aug-cli@next check .
npx @greenpandastudios/aug-cli@next spec .
npx @greenpandastudios/aug-cli@next run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/generic-di/.
