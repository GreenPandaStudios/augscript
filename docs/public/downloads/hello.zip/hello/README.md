# Hello world with dependencies

Print a greeting through an injected logger. Startup selects the providers, and export files choose what each folder makes public.

Install August as described at https://greenpandastudios.github.io/augscript/getting-started. Native commands prepare required libraries automatically.

From the folder containing this extracted project:

```sh
cd hello
aug check .
aug spec .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/hello/.
