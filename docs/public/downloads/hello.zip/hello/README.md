# Hello world with dependencies

The application prints a greeting through an injected logger. Its entry point selects the providers, and each folder exposes a small public surface.

Install August as described at https://greenpandastudios.github.io/augscript/getting-started. Native commands prepare required libraries automatically.

From the folder containing this extracted project:

```sh
cd hello
aug check .
aug spec .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/hello/.
