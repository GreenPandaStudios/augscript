# Hello world with dependencies

The application prints a greeting through an injected logger. Its entry point selects the providers, and each folder exposes a small public surface.

Prepare native dependencies as described at https://greenpandastudios.github.io/augscript/packages#npm-registry.

From the folder containing this extracted project:

```sh
cd hello
npx @greenpandastudios/aug-cli@next check .
npx @greenpandastudios/aug-cli@next spec .
npx @greenpandastudios/aug-cli@next run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/hello/.
