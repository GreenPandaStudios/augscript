// aug-spec: "export.aug.md" explains this file. Read it before changes; refresh with aug spec.
export Greeter from greeter
