# HTTP benchmark

Serve the typed JSON endpoint used in the throughput measurements.

Prepare native dependencies as described at https://greenpandastudios.github.io/augscript/packages#npm-registry.

From the folder containing this extracted project:

```sh
cd http-benchmark
npx @greenpandastudios/aug-cli@next check .
npx @greenpandastudios/aug-cli@next spec .
npx @greenpandastudios/aug-cli@next run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/http-benchmark/.
