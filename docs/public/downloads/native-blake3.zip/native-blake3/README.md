# Hashing with Rust BLAKE3

Hash a buffer with the Rust BLAKE3 crate and compare a known digest.

Install the August 0.23.0 CLI on macOS 14+ ARM64 or GNU/Linux x64/ARM64 with glibc 2.36+. It obtains the verified LLVM compiler and native library artifacts automatically. See https://greenpandastudios.github.io/augscript/native-packages.

From the folder containing this extracted project:

```sh
cd native-blake3
aug install .
aug check .
aug spec .
aug test .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/native-blake3/.
