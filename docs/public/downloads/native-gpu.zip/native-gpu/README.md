# GPU workers

Create Metal buffers inside isolated workers, add vectors on the GPU, and return copied results. Requires the August 0.22 preview, Apple Silicon, and macOS 14 or later with an available Metal GPU.

Install August as described at https://greenpandastudios.github.io/augscript/getting-started. Native commands prepare required libraries automatically.

From the folder containing this extracted project:

```sh
cd native-gpu
aug check .
aug spec .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/native-gpu/.
