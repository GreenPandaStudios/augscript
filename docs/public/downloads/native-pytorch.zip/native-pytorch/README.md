# CPU tensors with PyTorch

Import real LibTorch from its public August package, add CPU tensors, and verify the elements and sum. Owned tensors are released when their scope ends.

This native LLVM preview requires the development August 0.21.0 compiler on macOS 14+ ARM64. The matching npm compiler release and compiler pack are not public yet. See https://greenpandastudios.github.io/augscript/native-packages for availability. The published 0.20.1 CLI cannot run this project.

From the folder containing this extracted project:

```sh
cd native-pytorch
aug install .
aug check .
aug spec .
aug test .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/native-pytorch/.
