# A database with SQLite

Create an in-memory SQLite database, insert a bound value, and query it. Borrow the database for updates; scope exit closes it.

Install the August 1.0.0 CLI on macOS 14+ ARM64 or GNU/Linux x64/ARM64 with glibc 2.36+. It obtains the verified LLVM compiler and native library artifacts automatically. See https://greenpandastudios.github.io/augscript/native-packages.

From the folder containing this extracted project:

```sh
cd native-sqlite
aug install .
aug check .
aug spec .
aug test .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/native-sqlite/.
