# A database with SQLite

Create an in-memory database, insert a labeled bound value, and query it through the real SQLite implementation. Mutation requires a borrow; scope exit closes the database.

This native LLVM preview requires the development August 0.21.0 compiler on macOS 14+ ARM64. The matching npm compiler release and compiler pack are not public yet. See https://greenpandastudios.github.io/augscript/native-packages for availability. The published 0.20.1 CLI cannot run this project.

From the folder containing this extracted project:

```sh
cd native-sqlite
aug install .
aug check .
aug spec .
aug test .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/native-sqlite/.
