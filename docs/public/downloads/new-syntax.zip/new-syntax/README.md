# Labeled calls and injection

Constructor injection, named inputs, ordinary functions, and same-file tests.

Install August as described at https://greenpandastudios.github.io/augscript/getting-started. Native commands prepare required libraries automatically.

From the folder containing this extracted project:

```sh
cd new-syntax
aug check .
aug spec .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/new-syntax/.
