# OpenID Connect login application

One executable hosts a login page, an OpenID Connect provider and client, session JWTs, and logout. Accounts, keys, and sessions are held in memory for this development demonstration.

Prepare native dependencies as described at https://greenpandastudios.github.io/augscript/packages#npm-registry.

From the folder containing this extracted project:

```sh
cd oidc-login
npx @greenpandastudios/aug-cli@next check .
npx @greenpandastudios/aug-cli@next spec .
npx @greenpandastudios/aug-cli@next test .
npx @greenpandastudios/aug-cli@next run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/oidc-login/.
