# Create a package

Publish a small arithmetic library through export.aug and test its public surface.

Install August as described at https://greenpandastudios.github.io/augscript/getting-started. Native commands prepare required libraries automatically.

From the folder containing this extracted project:

```sh
cd packages-math/math
aug check .
aug spec .
aug test .
aug pack .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/packages-math/.
