# Create a package

Publish a small arithmetic library through export.aug and test its public surface.

Prepare native dependencies as described at https://greenpandastudios.github.io/augscript/packages#npm-registry.

From the folder containing this extracted project:

```sh
cd packages-math/math
npx @greenpandastudios/aug-cli@next check .
npx @greenpandastudios/aug-cli@next spec .
npx @greenpandastudios/aug-cli@next test .
npx @greenpandastudios/aug-cli@next pack .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/packages-math/.
