# Create a package

Export an arithmetic function from a library and test it.

Install August as described at https://greenpandastudios.github.io/augscript/getting-started. Native commands prepare required libraries automatically.

From the folder containing this extracted project:

```sh
cd packages-math/math
aug check .
aug spec .
aug test .
aug pack .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/packages-math/.
