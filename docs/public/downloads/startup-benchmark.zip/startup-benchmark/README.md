# Startup benchmark

The small program used to measure process startup.

Prepare native dependencies as described at https://greenpandastudios.github.io/augscript/packages#npm-registry.

From the folder containing this extracted project:

```sh
cd startup-benchmark
npx @greenpandastudios/aug-cli@next check .
npx @greenpandastudios/aug-cli@next spec .
npx @greenpandastudios/aug-cli@next run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/startup-benchmark/.
