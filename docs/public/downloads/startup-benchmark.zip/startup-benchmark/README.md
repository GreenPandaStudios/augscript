# Startup benchmark

Print one integer and exit to measure process startup.

Install August as described at https://greenpandastudios.github.io/augscript/getting-started. Native commands prepare required libraries automatically.

From the folder containing this extracted project:

```sh
cd startup-benchmark
aug check .
aug spec .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/startup-benchmark/.
