# Private state and helpers

Keep underscore-prefixed implementation details inside their scope.

Install August as described at https://greenpandastudios.github.io/augscript/getting-started. Native commands prepare required libraries automatically.

From the folder containing this extracted project:

```sh
cd visibility
aug check .
aug spec .
aug run .
```

Read the source beside its compiled specification at https://greenpandastudios.github.io/augscript/examples/visibility/.
